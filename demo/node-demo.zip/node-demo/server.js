/**
 * Mini-PaaS 测试项目 · Node.js（零依赖，使用内置 http 模块）
 *
 * 用途：验证平台对 node 类型项目的完整链路
 *   package.json 识别 → npm install → npm start → 生成 Dockerfile
 *   → 构建镜像 → 部署容器 → 访问
 *
 * 容器端口：
 *   平台不会向 Node 应用注入端口，Dockerfile 里执行的是 `npm start`，
 *   直接运行本文件。因此请把创建向导里的"容器端口"填成 3000
 *   （平台对 node 类型的默认值），与本文件保持一致。
 *
 * 采用零依赖实现（不用 express），避免 npm 拉包失败干扰平台链路验证；
 * 若想顺带验证 NPM_REGISTRY 是否生效，可在 package.json 里加一个依赖。
 */

const http = require("http");
const os = require("os");

const PORT = Number(process.env.PORT) || 3000;
const STARTED_AT = new Date();

const PAGE = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Node 测试项目</title>
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0; min-height: 100vh; display: grid; place-items: center;
      font-family: system-ui, -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif;
      background: radial-gradient(1200px 600px at 50% -10%, #065f4633, transparent), #0b1220;
      color: #e2e8f0; padding: 24px;
    }
    .card {
      width: min(680px, 100%); background: #111a2e; border: 1px solid #1f2b45;
      border-radius: 16px; padding: 32px; box-shadow: 0 24px 60px #0009;
    }
    .badge {
      display: inline-block; padding: 4px 12px; border-radius: 999px; font-size: 12px;
      font-weight: 600; letter-spacing: .5px; background: #10b98122; color: #34d399;
      border: 1px solid #10b98155;
    }
    h1 { margin: 16px 0 8px; font-size: 24px; }
    p.sub { margin: 0 0 24px; color: #94a3b8; font-size: 14px; }
    .rows { border-top: 1px solid #1f2b45; }
    .row {
      display: flex; justify-content: space-between; gap: 16px;
      padding: 11px 0; border-bottom: 1px solid #1f2b45; font-size: 14px;
    }
    .row .k { color: #94a3b8; }
    .row .v { font-family: ui-monospace, Consolas, monospace; color: #6ee7b7; word-break: break-all; }
  </style>
</head>
<body>
  <div class="card">
    <span class="badge">NODE.JS</span>
    <h1>Node 测试项目运行成功</h1>
    <p class="sub">若能看到本页面，说明平台的 Node 构建链路已全部打通。</p>
    <div class="rows" id="rows"></div>
  </div>
  <script>
    fetch("/api/info").then(r => r.json()).then(d => {
      const rows = [
        ["项目类型", d.project_type],
        ["运行时", d.runtime],
        ["Node 版本", d.node],
        ["监听端口", d.port],
        ["容器主机名", d.hostname],
        ["启动时间", d.started_at],
      ];
      document.getElementById("rows").innerHTML = rows.map(
        ([k, v]) => '<div class="row"><span class="k">' + k +
                    '</span><span class="v">' + v + '</span></div>'
      ).join("");
    }).catch(() => {
      document.getElementById("rows").innerHTML =
        '<div class="row"><span class="k">接口</span>' +
        '<span class="v">/api/info 调用失败</span></div>';
    });
  </script>
</body>
</html>`;

const server = http.createServer((req, res) => {
  const url = (req.url || "/").split("?")[0];

  if (url === "/api/info") {
    const payload = {
      project_type: "node",
      runtime: "Node.js (内置 http 模块)",
      node: process.version,
      port: PORT,
      hostname: os.hostname(),
      started_at: STARTED_AT.toISOString(),
      status: "ok",
    };
    res.writeHead(200, { "Content-Type": "application/json; charset=utf-8" });
    res.end(JSON.stringify(payload, null, 2));
    return;
  }

  if (url === "/" || url === "/index.html") {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(PAGE);
    return;
  }

  res.writeHead(404, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify({ error: "not found", path: url }));
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`[node-demo] 服务已启动，监听 0.0.0.0:${PORT}`);
});