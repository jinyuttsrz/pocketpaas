"""演示项目内部 worker：把访问计数持久化到命名卷 /data。"""

import json
import os
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DATA_DIR = os.environ.get("DATA_DIR", "/data")
COUNTER_FILE = os.path.join(DATA_DIR, "counter.json")
_lock = threading.Lock()


def _read_payload() -> dict:
    try:
        with open(COUNTER_FILE, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return {
            "count": int(data.get("count") or 0),
            "updated_at": data.get("updated_at"),
        }
    except (OSError, ValueError, TypeError):
        return {"count": 0, "updated_at": None}


def _write_payload(count: int) -> dict:
    payload = {
        "count": count,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp_path = COUNTER_FILE + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False)
    os.replace(tmp_path, COUNTER_FILE)
    return payload


def increment() -> dict:
    with _lock:
        payload = _read_payload()
        return _write_payload(payload["count"] + 1)


class Handler(BaseHTTPRequestHandler):
    server_version = "PocketPaaSDemoWorker/1.0"

    def _json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler 接口
        path = self.path.split("?", 1)[0]
        if path == "/healthz":
            self._json(200, {"status": "ok", "service": "worker"})
        elif path == "/stats":
            self._json(200, {"service": "worker", **_read_payload()})
        elif path == "/incr":
            payload = increment()
            print(f"[worker] counter={payload['count']}", flush=True)
            self._json(200, {"service": "worker", **payload})
        else:
            self._json(404, {"error": "not found"})

    def log_message(self, fmt: str, *args) -> None:
        print(f"[worker] {self.address_string()} {fmt % args}", flush=True)


if __name__ == "__main__":
    os.makedirs(DATA_DIR, exist_ok=True)
    port = int(os.environ.get("PORT", "7000"))
    print(f"[worker] listening on :{port}, data dir {DATA_DIR}", flush=True)
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
