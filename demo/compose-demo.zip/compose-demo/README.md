# Compose 多容器演示项目

用于验证 PocketPaaS 的多容器 Compose 能力：多公开服务、内部服务 DNS、健康检查、命名卷持久化、
服务级指标 / 日志 / 终端 / 文件，以及蓝绿发布与一键回滚。

## 服务结构

| 服务 | 类型 | 端口 | 说明 |
|---|---|---|---|
| `web` | 公开（主入口） | 8000 | 服务端调用 API，渲染演示页面 |
| `api` | 公开（第二入口） | 9000 | 通过内部 DNS 调用 worker，对外返回 JSON |
| `worker` | 内部 | 7000 | 把累计访问次数写入命名卷 `counter-data` |

调用链：`web → api → worker`。`api` 与 `worker` 均配置了 `healthcheck`，
`web` 与 `api` 通过 `depends_on: service_healthy` 等待依赖就绪。

```text
x-paas:
  public: [web, api]   # 两个公开服务
  primary: web          # 主入口沿用应用域名，api 使用 {应用名}-api 子域名
```

## 页面表现

- 打开 `web` 入口：显示累计访问次数、当前 API 状态、两个服务的容器主机名和 API 原始 JSON。
- 点击「增加一次计数」：`web → api → worker` 递增计数并写入 `/data/counter.json`。
- 刷新页面不会增加计数（只读 `/status`）；点击按钮或直接访问 `api` 的 `/stats` 才会递增。
- 计数写入命名卷，重新部署 / 蓝绿切换后仍然保留；执行 `docker compose down -v` 才会清空。

## 在 PocketPaaS 中测试

1. 新建应用，容器端口填 `8000`。
2. 上传 `compose-demo.zip`，或在「模板与指南」页选择 `compose-demo`。
3. 构建并部署。
4. 概览「服务」区域应看到：
   - `web`：主入口、公开、独立宿主端口；
   - `api`：公开、独立宿主端口；
   - `worker`：内部、仅内网。
5. 用 web 的访问地址打开页面，点击「增加一次计数」验证链路。
6. 在服务选择器切到 `api` / `worker`，分别验证指标、实时日志、终端与文件。
7. 再次部署（蓝绿）：页面应在新端口继续可访问，旧槽位保留。
8. 在详情页点「回滚上一版本」，确认旧端口重新可访问。

## 验证清单

- [ ] 两个公开服务各分配独立宿主端口，主入口域名与 `api` 子域名均可访问。
- [ ] `web` 能通过内部 DNS 访问 `api`，`api` 能访问 `worker`。
- [ ] `depends_on: service_healthy` 生效，API 与 worker 健康后才启动上游。
- [ ] `worker` 的 `counter-data` 命名卷在重新部署后计数不丢失。
- [ ] 诊断页按服务分组展示 `web` / `api` / `worker`。
- [ ] 蓝绿发布后旧槽位停止，一键回滚可恢复。

## 本地直接运行（可选）

```bash
docker compose up --build
# 浏览器打开 http://localhost:8000
docker compose down -v
```

平台部署时会忽略 compose 中声明的宿主端口并重新分配，因此不会与本地运行的 8000 冲突。
