"""演示项目 API 服务：通过应用内 DNS 调用 worker，并对外提供二级公开入口。"""

import json
import os
import socket
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

WORKER_URL = os.environ.get("WORKER_URL", "http://worker:7000").rstrip("/")


def _fetch(path: str) -> dict:
    with urllib.request.urlopen(WORKER_URL + path, timeout=3) as response:
        return json.loads(response.read().decode("utf-8"))


def _worker_call(path: str) -> tuple[dict | None, str | None]:
    try:
        return _fetch(path), None
    except Exception as exc:  # noqa: BLE001 - 演示项目需把错误回传给页面
        return None, f"{type(exc).__name__}: {exc}"


class Handler(BaseHTTPRequestHandler):
    server_version = "PocketPaaSDemoApi/1.0"

    def _json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _payload(self, worker: dict | None, error: str | None) -> dict:
        return {
            "service": "api",
            "hostname": socket.gethostname(),
            "time": datetime.now(timezone.utc).isoformat(),
            "status": "ok" if error is None else "degraded",
            "worker": worker,
            "error": error,
        }

    def do_GET(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler 接口
        path = self.path.split("?", 1)[0]
        if path == "/healthz":
            self._json(200, {"status": "ok", "service": "api"})
        elif path in ("/", "/status"):
            worker, error = _worker_call("/stats")
            self._json(200, self._payload(worker, error))
        elif path == "/stats":
            worker, error = _worker_call("/incr")
            self._json(200, self._payload(worker, error))
        else:
            self._json(404, {"error": "not found"})

    def log_message(self, fmt: str, *args) -> None:
        print(f"[api] {self.address_string()} {fmt % args}", flush=True)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "9000"))
    print(f"[api] listening on :{port}, worker={WORKER_URL}", flush=True)
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
