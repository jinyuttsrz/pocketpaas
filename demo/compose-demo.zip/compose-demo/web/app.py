"""演示项目 Web 服务：服务端调用 API，展示多容器内部链路与命名卷计数。"""

import html
import json
import os
import socket
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

API_URL = os.environ.get("API_URL", "http://api:9000").rstrip("/")


def _api(path: str) -> tuple[dict | None, str | None]:
    try:
        with urllib.request.urlopen(API_URL + path, timeout=3) as response:
            return json.loads(response.read().decode("utf-8")), None
    except Exception as exc:  # noqa: BLE001 - 演示项目需把错误展示到页面
        return None, f"{type(exc).__name__}: {exc}"


def _render(data: dict | None, error: str | None) -> str:
    worker = (data or {}).get("worker") or {}
    count = worker.get("count", "—")
    updated = html.escape(str(worker.get("updated_at") or "尚未写入"))
    api_state = html.escape(str((data or {}).get("status") or "unknown"))
    hostname = html.escape(str((data or {}).get("hostname") or "—"))
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    error_html = (
        f'<div class="alert">API 暂不可用：{html.escape(error)}</div>' if error else ""
    )
    pretty = html.escape(json.dumps(data, ensure_ascii=False, indent=2)) if data else "null"
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta http-equiv="refresh" content="15" />
  <title>PocketPaaS · Compose Demo</title>
  <style>
    :root {{ color-scheme: light; }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0; min-height: 100vh; padding: 40px 20px;
      font-family: system-ui, -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif;
      color: #0f172a; background: #f8fafc;
    }}
    .wrap {{ max-width: 760px; margin: 0 auto; }}
    .card {{
      background: #fff; border: 1px solid #e2e8f0; border-radius: 14px;
      padding: 28px; box-shadow: 0 12px 32px rgba(15, 23, 42, .08);
    }}
    h1 {{ margin: 0 0 6px; font-size: 22px; letter-spacing: -.01em; }}
    .sub {{ color: #64748b; font-size: 13px; }}
    .chain {{ display: flex; flex-wrap: wrap; gap: 8px; margin: 22px 0; }}
    .node {{
      flex: 1 1 150px; padding: 12px 14px; border: 1px solid #e2e8f0;
      border-radius: 10px; background: #f8fafc;
    }}
    .node b {{ display: block; font-size: 13px; }}
    .node span {{ color: #64748b; font-size: 11.5px; }}
    .node.public {{ border-color: #bae6fd; background: #eff6ff; }}
    .node.internal {{ border-color: #ddd6fe; background: #f5f3ff; }}
    .metric {{ display: flex; align-items: baseline; gap: 10px; margin: 22px 0 10px; }}
    .metric strong {{ font-size: 46px; line-height: 1; letter-spacing: -.03em; }}
    .metric span {{ color: #64748b; font-size: 12.5px; }}
    .actions {{ display: flex; gap: 8px; flex-wrap: wrap; }}
    .btn {{
      display: inline-block; padding: 8px 14px; border-radius: 8px;
      font-size: 13px; text-decoration: none; border: 1px solid #e2e8f0; color: #334155;
    }}
    .btn-primary {{ background: #0f172a; border-color: #0f172a; color: #fff; }}
    .alert {{
      margin-top: 18px; padding: 10px 12px; border-radius: 8px;
      background: #fef2f2; border: 1px solid #fecaca; color: #dc2626; font-size: 12.5px;
    }}
    .meta {{ display: flex; flex-wrap: wrap; gap: 16px; margin-top: 18px; color: #64748b; font-size: 12px; }}
    pre {{
      margin: 18px 0 0; padding: 14px; border-radius: 10px; background: #0f172a;
      color: #e2e8f0; font-size: 12px; line-height: 1.55; overflow: auto;
      font-family: ui-monospace, Consolas, monospace;
    }}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1>PocketPaaS · 多容器 Compose 演示</h1>
      <div class="sub">Web → API → Worker：内部 DNS、健康检查、命名卷与多公开服务</div>
      {error_html}
      <div class="chain">
        <div class="node public"><b>web</b><span>主入口 · 本页</span></div>
        <div class="node public"><b>api</b><span>第二公开服务 · {api_state}</span></div>
        <div class="node internal"><b>worker</b><span>内部服务 · 计数持久化</span></div>
      </div>
      <div class="metric">
        <strong>{html.escape(str(count))}</strong>
        <span>累计访问次数（写入命名卷 counter-data）</span>
      </div>
      <div class="actions">
        <a class="btn btn-primary" href="/bump">增加一次计数</a>
        <a class="btn" href="/">刷新</a>
      </div>
      <div class="meta">
        <span>web 主机：{html.escape(socket.gethostname())}</span>
        <span>api 主机：{hostname}</span>
        <span>计数更新时间：{updated}</span>
        <span>页面时间：{now}</span>
      </div>
      <pre>{pretty}</pre>
    </div>
  </div>
</body>
</html>"""


class Handler(BaseHTTPRequestHandler):
    server_version = "PocketPaaSDemoWeb/1.0"

    def _send_html(self, status: int, body: str) -> None:
        data = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler 接口
        path = self.path.split("?", 1)[0]
        if path == "/healthz":
            data = b"ok"
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if path == "/bump":
            _api("/stats")
            self.send_response(303)
            self.send_header("Location", "/")
            self.end_headers()
            return
        if path != "/":
            self._send_html(404, "<h1>404</h1>")
            return
        data, error = _api("/status")
        print(f"[web] render count={((data or {}).get('worker') or {}).get('count')}", flush=True)
        self._send_html(200, _render(data, error))

    def log_message(self, fmt: str, *args) -> None:
        print(f"[web] {self.address_string()} {fmt % args}", flush=True)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8000"))
    print(f"[web] listening on :{port}, api={API_URL}", flush=True)
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
