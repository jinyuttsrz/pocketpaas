"""Mini-PaaS 测试项目 · Python（FastAPI）

用途：验证平台对 python 类型项目的完整链路
    requirements.txt 识别 → 自动选择 uvicorn（ASGI）→ 容器端口注入
    → 生成 Dockerfile → 构建镜像 → 部署容器 → 访问

识别约定：
    本文件含 `app = FastAPI(...)`，平台会将入口推断为 main:app。

容器端口：
    平台会把创建向导里填的端口注入 `uvicorn --port`，
    所以此处填任意端口都能自动对齐（建议保持默认 8000）。
"""

import platform
import socket
from datetime import datetime

from fastapi import FastAPI
from fastapi.responses import HTMLResponse

app = FastAPI(title="Mini-PaaS Python 测试项目")

PAGE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Python 测试项目 · FastAPI</title>
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0; min-height: 100vh; display: grid; place-items: center;
      font-family: system-ui, -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif;
      background: radial-gradient(1200px 600px at 50% -10%, #1e3a8a33, transparent), #0b1220;
      color: #e2e8f0; padding: 24px;
    }
    .card {
      width: min(680px, 100%); background: #111a2e; border: 1px solid #1f2b45;
      border-radius: 16px; padding: 32px; box-shadow: 0 24px 60px #0009;
    }
    .badge {
      display: inline-block; padding: 4px 12px; border-radius: 999px; font-size: 12px;
      font-weight: 600; letter-spacing: .5px; background: #0ea5e922; color: #38bdf8;
      border: 1px solid #0ea5e955;
    }
    h1 { margin: 16px 0 8px; font-size: 24px; }
    p.sub { margin: 0 0 24px; color: #94a3b8; font-size: 14px; }
    .rows { border-top: 1px solid #1f2b45; }
    .row {
      display: flex; justify-content: space-between; gap: 16px;
      padding: 11px 0; border-bottom: 1px solid #1f2b45; font-size: 14px;
    }
    .row .k { color: #94a3b8; }
    .row .v { font-family: ui-monospace, Consolas, monospace; color: #7dd3fc; word-break: break-all; }
    .ok { color: #4ade80; font-weight: 600; }
  </style>
</head>
<body>
  <div class="card">
    <span class="badge">PYTHON · FASTAPI</span>
    <h1>Python 测试项目运行成功</h1>
    <p class="sub">若能看到本页面，说明平台的 Python 构建链路已全部打通。</p>
    <div class="rows" id="rows"></div>
  </div>
  <script>
    fetch("/api/info").then(r => r.json()).then(d => {
      const rows = [
        ["项目类型", d.project_type],
        ["框架", d.framework],
        ["运行服务器", d.server],
        ["Python 版本", d.python],
        ["容器主机名", d.hostname],
        ["当前时间", d.time],
      ];
      document.getElementById("rows").innerHTML = rows.map(
        ([k, v]) => '<div class="row"><span class="k">' + k +
                    '</span><span class="v">' + v + '</span></div>'
      ).join("");
    }).catch(() => {
      document.getElementById("rows").innerHTML =
        '<div class="row"><span class="k">接口</span>' +
        '<span class="v">/api/info 调用失败</span></div>';
    });
  </script>
</body>
</html>
"""


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    """测试首页。"""
    return PAGE


@app.get("/api/info")
def info() -> dict:
    """返回运行时信息，便于在控制台/浏览器核对容器内真实状态。"""
    return {
        "project_type": "python",
        "framework": "FastAPI",
        "server": "uvicorn",
        "python": platform.python_version(),
        "hostname": socket.gethostname(),
        "time": datetime.now().isoformat(timespec="seconds"),
        "status": "ok",
    }